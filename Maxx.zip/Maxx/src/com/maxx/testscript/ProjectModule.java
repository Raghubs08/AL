package com.maxx.testscript;

public class ProjectModule {
	public void createProject() {
		
	}
	public void deleteProject() {
		
	}
}
